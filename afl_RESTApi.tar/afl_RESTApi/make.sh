 make clean
 make
 make install
