

#include <stdio.h>

#include "abJSON.h"
#include "abJSON_type.h"


/* ���ֺ���ָ�� */
typedef void (*fptr_a)(cJSON*);


/* ˽�к������� */
static u32 get_file_size(FILE* fp);
static void traverse_json_node(cJSON* node, fptr_a pre_operation, fptr_a mid_operation, fptr_a post_operation);    /* ����JSON�ڵ�������ֵܼ�����ڵ㣬���ִ��operation������ע��operation���ҽ���һ��cJSON*���͵Ĳ��� */
static void free_this_node(cJSON* node);                          /* �ͷ�ĳJSON�ڵ�����Ķ����ڴ棬������ָ�븳ֵΪNULL */
static u32 rs_hash(u8* str, u32 len);
//static u32 get_param_info_idx_by_cJSON(cJSON** params_map, cJSON* node);


/* �������� */
/* JSON�������� */

void abJSON_show_json_tree(cJSON* node) {

    if (node == NULL) return;
  
    fptr_a print_node = &abJSON_print_node_info;
    traverse_json_node(node, print_node, 0, 0);
}

void abJSON_print_node_info(cJSON* node) {

    if (node == NULL) return;

    printf("\nname: %s\n", node->string);
    printf("type: %d\n", node->type);
    printf("valuestring: %s\n", node->valuestring);
    printf("vlaueint: %d\n", node->valueint);
    printf("valuedouble: %d\n\n", node->valuedouble);
    return;
}

cJSON* abJSON_get_parent_node(cJSON* child, cJSON* root) {
    
    if (child == NULL || root == NULL) return;

    cJSON* cur_node = root;

    cJSON_Queue* queue;

    queue = init_queue();

    while (cur_node || !queue_is_empty(queue)) {

        //print_queue(queue);

        if (cur_node) {

            if (ck_type(cur_node) == OBJECT) {
                cJSON* tmp_node = cJSON_GetObjectItem(cur_node, child->string);
                if (tmp_node != NULL && tmp_node == child) return cur_node;
            }

            enqueue(queue, cur_node);
            cur_node = cur_node->next;

        }
        else {

            cur_node = dequeue(queue)->child;

        }

    }

    free_queue(queue);

}


u16 abJSON_get_schema_type(cJSON* node) {

    if (node == NULL) return;
    
    cJSON* schema_type_node = NULL;
    if ((schema_type_node = cJSON_GetObjectItem(node, "type")) == NULL) return;

    u16* schema_type = NULL;
    if ((schema_type = schema_type_node->valuestring) == NULL) return;

    u32 schema_type_hash = rs_hash(schema_type, ALLOC_sz(schema_type_node->valuestring));

    switch (schema_type_hash) {
    // string 
    case STRING_HASH:
        return STRING;

    // interger
    case INTEGER_HASH:
        return INTEGER;

    // number
    case NUMBER_HASH:
        return NUMBER;

    // null
    case NULL_HASH:
        return NUL;

    // object
    case OBJECT_HASH:
        return OBJECT;

    // array
    case ARRAY_HASH:
        return ARRAY;

    // boolean
    case BOOLEAN_HASH:
        return BOOLEAN;

    // unsport type
    default:
        PFATAL("[!] Undefined schema type: %s.\n", schema_type);
    }

    

    /*
    if (!!strncmp(schema_type, "string", 6)) return STRING;
    else if (!!strncmp(schema_type, "integer", 7)) return INTEGER;
    else if (!!strncmp(schema_type, "number", 6)) return INTEGER;
    else if (!!strncmp(schema_type, "array", 5)) return INTEGER;
    else if (!!strncmp(schema_type, "object", 3)) return INTEGER;
    else if (!!strncmp(schema_type, "null", 4)) return INTEGER;
    else if (!!strncmp(schema_type, "boolean", 7)) return INTEGER;
    else PFATAL("[!] Undefined schema type: %s.\n", schema_type);
    /
    /*
    switch (*schema_type) {
    
    // string 
    case 0x73:
        return STRING;

    // interger
    case 0x69:
        return INTEGER;

    // number || null
    case 0x6E:
        if (!!strncmp(schema_type, "number", 6)) return NUMBER;
        else if (!!strncmp(schema_type, "null", 4)) return NUL;
        PFATAL("[!] Undefined schema type: %s.\n", schema_type);

    // object
    case 0x6F:
        return OBJECT;

    // array
    case 0x61:
        return ARRAY;

    // boolean
    case 0x62:
        return BOOLEAN;

    // unsport type
    default: 
        PFATAL("[!] Undefined schema type: %s.\n", schema_type);
    }
   */


}


void abJSON_append_new_schema_entry(schema_list* schema_info, schema_entry* new_schema_entry) {

    if (new_schema_entry == NULL) return;

    if (schema_info->num == 0) {
        new_schema_entry->next = NULL;
        new_schema_entry->prev = NULL;
        schema_info->head = new_schema_entry;
        schema_info->tail = new_schema_entry;
        schema_info->num += 1;
    }
    else {
        new_schema_entry->next = NULL;
        new_schema_entry->prev = schema_info->tail;
        schema_info->tail->next = new_schema_entry;
        schema_info->tail = new_schema_entry;
        schema_info->num += 1;
    }
}

void abJSON_print_schmea_list(schema_list _schema_list) {

    if (_schema_list.num == 0) return;

    schema_entry* cur_schema = _schema_list.head;

    while (cur_schema != NULL) {

        printf("schema master node: %s\n", cur_schema->master->string);
        printf("schema type: %d\n", cur_schema->type);
        if (cur_schema->type == ENUM) {
            printf("schema enum: \n");
            for (u32 idx = 0; idx < ALLOC_S(cur_schema->extend_schema_info->value_enum) / sizeof(u8*); idx++) {
                printf("\t%s\n", cur_schema->extend_schema_info->value_enum[idx]);
            }
        }

        printf("\n");

        cur_schema = cur_schema->next;
    }

}

void abJSON_print_params_info(param_entry* params_info) {

    if (params_info == NULL)return;

    u32 params_num = ALLOC_S(params_info) / sizeof(param_entry);

    for (u32 info_idx = 0; info_idx < params_num; info_idx++) {
        printf("param_info[%d].name = %s\n", info_idx, params_info[info_idx].name);
        printf("param_info[%d].type = %d\n", info_idx, params_info[info_idx].type);
        printf("param_info[%d].value = %s\n", info_idx, params_info[info_idx].value);
        printf("%d\n", !!(params_info[info_idx].type & SPECIAL_MUTATE_TYPE));
        puts("");
    }
}

void abJSON_print_params_map(cJSON** params_map) {
    if (params_map == NULL)return;

    u32 params_num = ALLOC_S(params_map) / sizeof(cJSON*);

    for (u32 info_idx = 0; info_idx < params_num; info_idx++) {
        printf("param_map[%d].name = %s\n", info_idx, params_map[info_idx]->string);
        printf("param_map[%d].type = %d\n", info_idx, params_map[info_idx]->type);
        printf("param_map[%d].value = %s\n", info_idx, params_map[info_idx]->valuestring);
        puts("");
    }
}





/* Queue�������� */
cJSON_Queue* init_queue() {
    
    cJSON_Queue* ret = (cJSON_Queue*)ck_alloc(sizeof(cJSON_Queue));

    if (!ret) PFATAL("%s\n", "[!] Queue init error.");

    ret->node_array = (cJSON**)ck_alloc(QUEUE_INIT_SIZE * sizeof(cJSON*));
    ret->size = QUEUE_INIT_SIZE;
    ret->front = 0;
    ret->rear = ret->size - 1;

    return ret;
}

void enqueue(cJSON_Queue* queue, cJSON* node) {

    if (queue == NULL) return;

    if ((queue->rear + 2) % queue->size == queue->front) {

        queue->node_array = (cJSON**)realloc(queue->node_array, queue->size + QUEUE_INIT_SIZE * sizeof(cJSON*));

        if (!queue->node_array) PFATAL("%s\n", "[!] Enqueue error: realloc failed.");

        queue->size = queue->size + QUEUE_INIT_SIZE;

    }

    queue->rear = (queue->rear + 1) % queue->size;
    queue->node_array[queue->rear] = node;
    
}

cJSON* dequeue(cJSON_Queue* queue) {

    if (queue->front == (queue->rear + 1) % queue->size) PFATAL("%s\n", "[!] Dequeue error: empty queue.");

    cJSON* tmp = queue->node_array[queue->front];

    queue->front = (queue->front + 1) % queue->size;

    return tmp;

}

u32 queue_is_empty(cJSON_Queue* queue) {

    if (queue == NULL) PFATAL("%s\n", "[!] NULL ptr: queue_is_empty.");
    

    if ((queue->rear + 1) % queue->size == queue->front) return 1;
    return 0;

}

void print_queue(cJSON_Queue* queue) {

    if (queue == NULL) PFATAL("%s\n", "[!] NULL ptr: print_queue.");

    if (queue_is_empty(queue)) {
        puts("==========================================");
        return;
    }

    u32 cnt = queue->front;
    for (u32 cur = 0; cur <= (queue->rear - queue->front + queue->size) % queue->size; cur++) {
        printf("%d:%d / %d\n", queue->front, queue->rear, cnt % queue->size);
        abJSON_print_node_info(queue->node_array[cnt++ % queue->size]);
    }

    puts("==========================================");

}

void free_queue(cJSON_Queue* queue) {
    ck_free(queue->node_array);
    ck_free(queue);
}

/* ��ʼ������ */
u8* read_json_from_file(const char* filePath) {
    FILE* fp = NULL;
    char* jsonBuf = NULL;
    int jsonSize;

    fp = fopen(filePath, "r");

    if (!fp) PFATAL("Unable to open '%s'", filePath);

    jsonSize = get_file_size(fp);

    jsonBuf = ck_alloc(jsonSize + 1);

    //remember to free JSONBuf after use
    //ck_read(fp, jsonBuf, jsonSize, filePath);
    if (jsonBuf) {
        fread(jsonBuf, jsonSize + 1, sizeof(char), fp);
        jsonBuf[jsonSize] = '\0';
    }

    fclose(fp);

    return jsonBuf;
}

u8 ck_modifier(cJSON* node) {
    if (node->string == NULL) return NORMAL;

    switch (*(u8*)(node->string)) {
    case '@':
        return STATIC;

    case '!':
        return REQUIRE;

    default:
        return NORMAL;
    }
}

u16 ck_type(cJSON* node) {

    if (node == NULL) return;

    switch (node->type) {
    case 0:
        return INVALID;

    case 1:
        return BOOLEAN;

    case 2:
        return BOOLEAN;

    case 4:
        return NUL;

    case 8:
        return INTEGER;

    case 16:
        return STRING;

    case 32:
        return ARRAY;

    case 64:
        return OBJECT;

    default:
        PFATAL("[!] Wrong JSON node type at node \"%s\".\n", node->string);
        return;
    }
}

BOOL ck_mutable(cJSON* node) {

    if (node == NULL) return;

    switch (ck_type(node)) {
    case INTEGER:
        return True;

    case NUMBER:
        return True;

    case STRING:
        return True;

    case BOOLEAN:
        return True;
    
    default:
        return False;
    }
}

cJSON* ck_json_format(u8* json_stream) {

    cJSON* maybe_root = NULL;

    if ((maybe_root = cJSON_Parse(json_stream)) == NULL) {
        const u8* json_error = cJSON_GetErrorPtr();

        cJSON_Delete(maybe_root);

        PFATAL("JSON format error. Error before: %s\n", json_error);

        return NULL;
    }

    return maybe_root;

}

BOOL ck_is_schema(cJSON* node) {
    
    if (node == NULL) return;

    if (node->string == NULL) return False;

    if (!!strncmp(node->string, "@schema", 7)) return False;

    return True;
}

BOOL ck_has_schema(cJSON* node) {

    if (node == NULL) return;

    if (node->child == NULL) return;

    cJSON* child_node = node->child;

    u32 schema_cnt = 0;

    do {
        if (ck_is_schema(child_node)) schema_cnt++;
    } while ((child_node = child_node->next) != NULL);

    if (schema_cnt > 1) PFATAL("[!] JSON Error, two schema under node %s\n", node->string);
    if (schema_cnt == 1) return True;
    return False;

}


s32 hex2num(u8* hex_str) {
    s32 res = 0;
    while (*hex_str != '\0') {
        if (*hex_str >= '0' && *hex_str <= '9') {
            res = (res << 4) + ((s32)*hex_str - '0');
        }
        else if (*hex_str >= 'a' && *hex_str <= 'f') {
            res = (res << 4) + 10 + ((s32)*hex_str - 'a');
        }
        else {
            res = (res << 4) + 10 + ((s32)*hex_str - 'A');
        }
        hex_str++;
    }
    return res;
}

u8* num2hex(s32 num) {
    u8* num_str[17] = { 0 };
    sprintf(num_str, "%04X\0", num);
    return num_str;
}

/* ������������ */



/* ˽�к��� */

//Gets the current file size.
static u32 get_file_size(FILE* fp) {
    int fileSize;

    fseek(fp, 0, SEEK_END);
    fileSize = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    return fileSize;
}

static void traverse_json_node(cJSON* node, fptr_a pre_operation, fptr_a mid_operation, fptr_a post_operation) {
    if (node == NULL) return;

    if (pre_operation != NULL) pre_operation(node);

    if (node->child != NULL) {
        traverse_json_node(node->child, pre_operation, mid_operation, post_operation);
    }

    if (mid_operation != NULL) mid_operation(node);


    if (node->next != NULL) {
        traverse_json_node(node->next, pre_operation, mid_operation, post_operation);
    }

    if (post_operation != NULL) post_operation(node);
}

static void free_this_node(cJSON* node) {
    if (node == NULL) return;
    
    node->next = NULL;
    node->prev = NULL;
    node->child = NULL;
    cJSON_free(node->string);
    cJSON_free(node->valuestring);
    cJSON_free(node);

    return;
}

static u32 rs_hash(u8* str, u32 len) {
    unsigned int hash = 1315423911;

    unsigned int i = 0;

    for (i = 0; i < len; str++, i++)

    {

        hash ^= ((hash << 5) + (*str) + (hash >> 2));

    }

    return hash;
}




/* ˽�к������� */







/* Ӧ��ɾ���ĺ��� */


/* Ӧ��ɾ���ĺ������� */
