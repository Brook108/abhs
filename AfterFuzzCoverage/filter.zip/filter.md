<p>N_3053 :  ['StockCode', 'Direction', 'OrderPrice', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3053.svg?raw=true" />
N_2775 :  ['StockCode', 'SeatNo', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2775.svg?raw=true" />
N_2774 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2774.svg?raw=true" />
N_39 :  ['OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/39.svg?raw=true" />
N_1445 :  ['SeatNo']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1445.svg?raw=true" />
N_3050 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3050.svg?raw=true" />
N_1109 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1109.svg?raw=true" />
N_2776 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2776.svg?raw=true" />
N_2777 :  ['StockCode', 'SeatNo', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2777.svg?raw=true" />
N_2788 :  ['StockCode', 'SeatNo', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2788.svg?raw=true" />
N_1083 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1083.svg?raw=true" />
N_3051 :  ['StockCode', 'Direction', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3051.svg?raw=true" />
N_3723 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3723.svg?raw=true" />
N_3535 :  ['OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3535.svg?raw=true" />
N_16 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/16.svg?raw=true" />
N_3069 :  ['ExchangeID', 'StockCode', 'Direction', 'OrderPrice', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3069.svg?raw=true" />
N_3041 :  ['OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3041.svg?raw=true" />
N_1130 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1130.svg?raw=true" />
N_3055 :  ['StockCode', 'Direction', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3055.svg?raw=true" />
N_2767 :  ['StockCode', 'OrderPrice', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2767.svg?raw=true" />
N_2772 :  ['StockCode', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2772.svg?raw=true" />
N_3040 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3040.svg?raw=true" />
N_3068 :  ['StockCode', 'SeatNo', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3068.svg?raw=true" />
N_17 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/17.svg?raw=true" />
N_1443 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1443.svg?raw=true" />
N_262 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/262.svg?raw=true" />
N_1084 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1084.svg?raw=true" />
N_2214 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2214.svg?raw=true" />
N_2764 :  ['StockCode', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2764.svg?raw=true" />
N_2770 :  ['StockCode', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2770.svg?raw=true" />
N_2771 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2771.svg?raw=true" />
N_2765 :  ['StockCode', 'Direction', 'OrderPrice', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2765.svg?raw=true" />
N_3692 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3692.svg?raw=true" />
N_3725 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3725.svg?raw=true" />
N_3043 :  ['StockCode', 'OrderPrice', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3043.svg?raw=true" />
N_3057 :  ['ExchangeID', 'StockCode', 'SeatNo', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3057.svg?raw=true" />
N_14 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/14.svg?raw=true" />
N_3232 :  ['Direction', 'OrderPrice', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3232.svg?raw=true" />
N_3227 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3227.svg?raw=true" />
N_3233 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3233.svg?raw=true" />
N_3225 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3225.svg?raw=true" />
N_3231 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3231.svg?raw=true" />
N_64 :  ['StockCode', 'SeatNo', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/64.svg?raw=true" />
N_1181 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1181.svg?raw=true" />
N_1157 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1157.svg?raw=true" />
N_59 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/59.svg?raw=true" />
N_3234 :  ['SeatNo']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3234.svg?raw=true" />
N_1184 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1184.svg?raw=true" />
N_3355 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3355.svg?raw=true" />
N_1185 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1185.svg?raw=true" />
N_3207 :  ['OrderPrice']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3207.svg?raw=true" />
N_1148 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1148.svg?raw=true" />
N_3367 :  ['StockCode', 'Direction', 'OrderPrice', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3367.svg?raw=true" />
N_3372 :  ['OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3372.svg?raw=true" />
N_3038 :  ['ExchangeID', 'StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3038.svg?raw=true" />
N_53 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/53.svg?raw=true" />
N_3204 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3204.svg?raw=true" />
N_3238 :  ['OrderPrice']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3238.svg?raw=true" />
N_3370 :  ['OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3370.svg?raw=true" />
N_3371 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3371.svg?raw=true" />
N_3198 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3198.svg?raw=true" />
N_3205 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3205.svg?raw=true" />
N_3229 :  ['Direction', 'OrderPrice']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3229.svg?raw=true" />
N_55 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/55.svg?raw=true" />
N_5 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/5.svg?raw=true" />
N_57 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/57.svg?raw=true" />
N_42 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/42.svg?raw=true" />
N_19 :  ['OrderPrice']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/19.svg?raw=true" />
N_25 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/25.svg?raw=true" />
N_1103 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1103.svg?raw=true" />
N_2542 :  ['OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2542.svg?raw=true" />
N_2768 :  ['StockCode', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2768.svg?raw=true" />
N_2769 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2769.svg?raw=true" />
N_3067 :  ['ExchangeID', 'StockCode', 'SeatNo', 'Direction', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3067.svg?raw=true" />
N_1102 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/1102.svg?raw=true" />
N_24 :  ['StockCode', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/24.svg?raw=true" />
N_18 :  ['StockCode', 'OrderPrice']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/18.svg?raw=true" />
N_26 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/26.svg?raw=true" />
N_3059 :  ['IPAddress', 'VolSerialNo', 'TerminalInfo', 'ExchangeID', 'SeatNo', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3059.svg?raw=true" />
N_3058 :  ['ExchangeID', 'SeatNo', 'Direction', 'OrderPrice', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3058.svg?raw=true" />
N_3070 :  ['StockCode', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3070.svg?raw=true" />
N_3064 :  ['StockCode', 'Direction', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3064.svg?raw=true" />
N_2391 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2391.svg?raw=true" />
N_23 :  ['StockCode']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/23.svg?raw=true" />
N_3060 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3060.svg?raw=true" />
N_2418 :  ['ExchangeID']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2418.svg?raw=true" />
N_2544 :  ['OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2544.svg?raw=true" />
N_3061 :  ['Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3061.svg?raw=true" />
N_22 :  ['StockCode', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/22.svg?raw=true" />
N_20 :  ['StockCode', 'Direction', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/20.svg?raw=true" />
N_2786 :  ['OrderRef', 'ExchangeID', 'StockCode', 'Direction', 'OrderPrice', 'OrderVolume', 'OrderCommand']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/2786.svg?raw=true" />
N_3062 :  ['OrderRef', 'ExchangeID', 'StockCode', 'Direction', 'OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3062.svg?raw=true" />
N_3710 :  ['OrderVolume']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/3710.svg?raw=true" />
N_21 :  ['StockCode', 'Direction']:
<img alt="alt text" src="https://raw.githubusercontent.com/Brook108/abhs/main//ModifiedSvg/21.svg?raw=true" /></p>